"""
config.py — Central parameter store for the StatArb engine.

All magic numbers live here. Never hardcode values in other modules.
Change something once, it propagates everywhere.
"""

from dataclasses import dataclass, field
from typing import List


# ---------------------------------------------------------------------------
# Universe definition
# ---------------------------------------------------------------------------
# We screen S&P 500 stocks sector-by-sector.
# Pairs within the same sector share macro exposures → better cointegration.
SECTORS = {
    # Technology and consumer removed — momentum-driven stocks cause beta-lag
    # and break spread mean-reversion. Value/cyclical sectors cointegrate better.
    "financials":   ["JPM",  "BAC",  "WFC",  "GS",   "MS",   "C",    "BLK",
                     "SCHW", "USB",  "PNC",  "AXP",  "COF",  "TFC",  "FITB"],
    "energy":       ["XOM",  "CVX",  "COP",  "SLB",  "EOG",  "MPC",
                     "PSX",  "VLO",  "OXY",  "HAL",  "DVN",  "BKR"],
    "healthcare":   ["JNJ",  "UNH",  "PFE",  "ABBV", "MRK",  "TMO",  "ABT",
                     "DHR",  "BMY",  "AMGN", "GILD", "ISRG", "VRTX", "REGN"],
}

ALL_TICKERS: List[str] = [t for tickers in SECTORS.values() for t in tickers]


# ---------------------------------------------------------------------------
# Data parameters
# ---------------------------------------------------------------------------
@dataclass
class DataConfig:
    start_date:     str   = "2018-01-01"
    end_date:       str   = "2024-01-01"
    price_col:      str   = "Adj Close"   # adjusted for splits & dividends
    min_history:    int   = 252           # bars; drop tickers with less data
    cache_dir:      str   = "data/"


# ---------------------------------------------------------------------------
# Pair screening parameters
# ---------------------------------------------------------------------------
@dataclass
class ScreenConfig:
    # Cointegration
    coint_pvalue_threshold: float = 0.10   # relaxed to survive 2020-22 regime shifts
    min_half_life:          int   = 5      # days — too fast = noise
    max_half_life:          int   = 126    # days — too slow = no edge (~6 mo)
    min_correlation:        float = 0.50   # relaxed — sector pairs still correlated enough

    # Stationarity of the spread
    adf_pvalue_threshold:   float = 0.10   # relaxed in line with coint threshold

    # Universe: only test same-sector pairs
    cross_sector:           bool  = False


# ---------------------------------------------------------------------------
# Signal / spread parameters
# ---------------------------------------------------------------------------
@dataclass
class SignalConfig:
    zscore_window:      int   = 40     # faster reaction — 60 was too slow for these pairs
    entry_z:            float = 2.0    # open trade when |z| crosses this
    exit_z:             float = 0.5    # close trade when |z| returns here
    stop_z:             float = 3.5    # emergency stop-loss z threshold
    # Hedge ratio method: 'ols' | 'kalman'
    hedge_method:       str   = "ols"


# ---------------------------------------------------------------------------
# Risk / position sizing parameters
# ---------------------------------------------------------------------------
@dataclass
class RiskConfig:
    capital:            float = 100_000.0  # starting capital ($)
    max_pairs:          int   = 10          # max concurrent open pairs
    risk_per_trade:     float = 0.02        # fraction of capital risked per pair
    max_drawdown:       float = 0.20        # halt trading if DD exceeds this
    # Kelly fraction (0.5 = "half Kelly" — conservative, recommended)
    kelly_fraction:     float = 0.5
    commission_pct:     float = 0.000       # zero-commission brokers (Robinhood, IBKR Lite)
    slippage_pct:       float = 0.0005      # 0.05% market impact


# ---------------------------------------------------------------------------
# Backtest parameters
# ---------------------------------------------------------------------------
@dataclass
class BacktestConfig:
    # Walk-forward splits
    train_years:        int   = 2       # in-sample window
    test_years:         int   = 1       # out-of-sample window
    n_splits:           int   = 4       # how many WF folds to run

    # Re-screening frequency (how often we re-find pairs in-sample)
    rescreen_days:      int   = 63      # quarterly


# ---------------------------------------------------------------------------
# Master config: one object to pass around
# ---------------------------------------------------------------------------
@dataclass
class Config:
    data:     DataConfig     = field(default_factory=DataConfig)
    screen:   ScreenConfig   = field(default_factory=ScreenConfig)
    signal:   SignalConfig   = field(default_factory=SignalConfig)
    risk:     RiskConfig     = field(default_factory=RiskConfig)
    backtest: BacktestConfig = field(default_factory=BacktestConfig)
    sectors:  dict           = field(default_factory=lambda: SECTORS)


# Convenience singleton — import this in other modules
CFG = Config()
