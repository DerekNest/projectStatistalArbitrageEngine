"""
backtester.py — Event-driven backtesting engine.

CONCEPT: Event-driven vs vectorised backtesting
  Vectorised backtesting (numpy operations over the whole array) is fast
  but makes it easy to accidentally introduce look-ahead bias because you
  operate on the full matrix at once.

  Event-driven backtesting simulates trading day by day, in chronological
  order, as if you were live. Each "event" is a market open or close.
  State (positions, cash, equity) is carried forward explicitly.
  It's slower but much harder to cheat accidentally.

  For a resume project, event-driven is the right choice — it shows you
  understand the distinction.

CONCEPT: Dollar-neutral pairs book
  Each pair trade consists of two simultaneous positions:
    - Long leg:  +$N in the cheaper stock (relative to spread)
    - Short leg: -$N in the more expensive stock

  The portfolio is MARKET-NEUTRAL: long and short dollars cancel.
  Our P&L comes purely from spread convergence, not market direction.
  This is why stat arb can generate alpha in both bull and bear markets.

CONCEPT: Mark-to-market P&L
  Each day we revalue every open position at current market prices.
  P&L = sum of (current_price - entry_price) * shares for longs
      + sum of (entry_price - current_price) * shares for shorts

  Cash earns no return in this model (conservative assumption).
  Real implementations would add T-bill returns on short proceeds.

CONCEPT: Realistic cost modelling
  We deduct commission + slippage on EVERY trade leg.
  Slippage is modelled as a fixed percentage of notional — in reality
  it depends on trade size relative to ADV (average daily volume).
  For S&P 500 stocks at retail-ish sizes, 0.05% is conservative enough.
"""

import logging
import warnings
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from config import CFG, RiskConfig
from risk_manager import (
    DrawdownMonitor, kelly_size, volatility_target_size,
    compute_trade_cost, passes_quality_gate, portfolio_risk_report,
)

warnings.filterwarnings("ignore")
log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Trade record
# ---------------------------------------------------------------------------

@dataclass
class OpenTrade:
    pair:         str
    direction:    int        # +1 = long spread, -1 = short spread
    entry_date:   pd.Timestamp
    entry_price_y: float
    entry_price_x: float
    shares_y:     float      # positive = long, negative = short
    shares_x:     float
    entry_cost:   float      # transaction costs paid at entry
    hedge_ratio:  float


# ---------------------------------------------------------------------------
# Main backtester class
# ---------------------------------------------------------------------------

class PairsBacktester:
    """
    Event-driven backtester for a portfolio of pairs trades.

    Usage:
        bt = PairsBacktester(prices, signal_data, ranked_pairs, cfg)
        results = bt.run()
    """

    def __init__(
        self,
        prices:       pd.DataFrame,
        signal_data:  Dict[str, pd.DataFrame],   # from signal_generator
        ranked_pairs: pd.DataFrame,
        signal_stats: pd.DataFrame,
        spread_quality: pd.DataFrame,
        cfg:          RiskConfig = None,
    ):
        self.prices         = prices
        self.signal_data    = signal_data
        self.ranked_pairs   = ranked_pairs
        self.signal_stats   = signal_stats
        self.spread_quality = spread_quality
        self.cfg            = cfg or CFG.risk

        # Execution state
        self.cash           = self.cfg.capital
        self.equity         = self.cfg.capital
        self.open_trades:   Dict[str, OpenTrade] = {}

        # Logging
        self.equity_curve:  List[dict] = []
        self.closed_trades: List[dict] = []
        # Per-pair cumulative realised P&L — used for per-pair loss circuit breaker
        self.pair_realised_pnl: Dict[str, float] = {}
        self.dd_monitor     = DrawdownMonitor(
            soft_limit=self.cfg.max_drawdown * 0.5,
            hard_limit=self.cfg.max_drawdown,
        )

    # ------------------------------------------------------------------
    # Pre-flight: which pairs are approved for trading?
    # ------------------------------------------------------------------

    def _approved_pairs(self) -> List[str]:
        """
        Apply quality gate filters and return tradeable pair names.
        """
        approved = []
        for _, row in self.ranked_pairs.iterrows():
            pair_name = f"{row['ticker_y']}/{row['ticker_x']}"

            # Only consider pairs we have signals for
            if pair_name not in self.signal_data:
                continue

            # Fetch stats
            stats_row = self.signal_stats[self.signal_stats["pair"] == pair_name]
            qual_row  = self.spread_quality[self.spread_quality["pair"] == pair_name]

            if stats_row.empty or qual_row.empty:
                continue

            stats_dict = stats_row.iloc[0].to_dict()
            adf_p      = float(qual_row.iloc[0]["adf_pvalue"])

            ok, reason = passes_quality_gate(
                stats_dict,
                min_trades=2,
                min_adf_pvalue_threshold=CFG.screen.adf_pvalue_threshold,
                adf_pvalue=adf_p,
            )

            if ok:
                approved.append(pair_name)
            else:
                log.info(f"  Excluding {pair_name}: {reason}")

        log.info(f"Approved {len(approved)} pairs for trading: {approved}")
        return approved[:self.cfg.max_pairs]

    # ------------------------------------------------------------------
    # Position sizing
    # ------------------------------------------------------------------

    def _compute_position_size(
        self,
        pair_name:    str,
        signal_row:   pd.Series,
        price_y:      float,
        price_x:      float,
        scale:        float,
    ) -> Tuple[float, float, float]:
        """
        Compute dollar-neutral share counts for both legs.

        Returns (shares_y, shares_x, notional) or (0, 0, 0) if too small.
        """
        stats_row  = self.signal_stats[self.signal_stats["pair"] == pair_name]
        if stats_row.empty:
            return 0.0, 0.0, 0.0

        st = stats_row.iloc[0]
        win_rate = st["win_rate"] / 100.0
        avg_win  = st["avg_win"]
        raw_loss = st["avg_loss"]
        # Failsafe: 100% win-rate pairs have avg_loss=NaN or 0.0 — Kelly can't divide by zero.
        # Assign a theoretical loss of half the average win (conservative estimate).
        if pd.isna(raw_loss) or raw_loss == 0.0:
            avg_loss = -abs(avg_win) * 0.5
        else:
            avg_loss = raw_loss

        # Kelly fraction of capital
        f = kelly_size(win_rate, avg_win, avg_loss, self.cfg.kelly_fraction)
        if f <= 0:
            return 0.0, 0.0, 0.0

        # Dollar notional for the Y leg
        notional_y = self.equity * f * scale * self.cfg.risk_per_trade / 0.02
        # Cap at 15% of equity per pair (sanity check)
        notional_y = min(notional_y, self.equity * 0.15)

        shares_y   = notional_y / price_y
        hedge_ratio = float(signal_row["hedge_ratio"])
        notional_x  = shares_y * hedge_ratio * price_x
        shares_x    = notional_x / price_x

        if notional_y < 500:   # don't bother with tiny positions
            return 0.0, 0.0, 0.0

        return shares_y, shares_x, notional_y

    # ------------------------------------------------------------------
    # Core simulation loop
    # ------------------------------------------------------------------

    def run(self) -> dict:
        """
        Main backtest loop. Iterates over every trading day.
        Returns a dict of result DataFrames and metrics.
        """
        approved = self._approved_pairs()
        if not approved:
            log.error("No pairs approved for trading")
            return {}

        # Common date range
        all_dates = self.prices.index
        log.info(f"Running backtest: {all_dates[0].date()} → {all_dates[-1].date()}")
        log.info(f"Pairs: {approved}")

        for date in all_dates:
            # --- Mark-to-market open positions ---
            mtm_pnl = self._mark_to_market(date)

            # --- Update equity ---
            self.equity = self.cash + mtm_pnl
            scale = self.dd_monitor.update(self.equity)

            # --- Log equity curve ---
            open_pairs = list(self.open_trades.keys())
            self.equity_curve.append({
                "date":       date,
                "equity":     round(self.equity, 2),
                "cash":       round(self.cash, 2),
                "mtm_pnl":    round(mtm_pnl, 2),
                "n_open":     len(self.open_trades),
                "drawdown":   round(self.dd_monitor.current_dd * 100, 3),
                "dd_scale":   round(scale, 3),
                "open_pairs": "|".join(open_pairs),
            })

            # --- Check exits first (close before opening new) ---
            for pair_name in list(self.open_trades.keys()):
                if pair_name not in self.signal_data:
                    continue

                sig_df = self.signal_data[pair_name]
                if date not in sig_df.index:
                    continue

                row = sig_df.loc[date]

                # Exit if: signal flipped to flat OR portfolio DD stop hit
                if row["trade_close"] or (scale == 0.0):
                    self._close_trade(pair_name, date, row, scale == 0.0)
                    continue

                # Per-pair loss circuit breaker:
                # If a single pair has lost more than max_loss_per_pair of
                # starting capital since it was approved, force-close it and
                # blacklist it for the rest of this backtest run.
                # This is what would have stopped IR/ITW from losing $12k.
                max_loss_cap = getattr(self.cfg, "max_loss_per_pair", 0.03)
                pair_loss = self.pair_realised_pnl.get(pair_name, 0.0)
                if pair_loss < -(self.cfg.capital * max_loss_cap):
                    log.info(f"  PAIR LOSS CAP hit: {pair_name} "
                             f"cumulative_loss=${pair_loss:+,.0f} — force-closing and blacklisting")
                    self._close_trade(pair_name, date, row, forced=True)
                    # Blacklist: remove from approved list so it cannot re-open
                    if pair_name in approved:
                        approved = [p for p in approved if p != pair_name]

            # --- Open new trades ---
            n_open = len(self.open_trades)
            for pair_name in approved:
                if pair_name in self.open_trades:
                    continue  # already in this pair
                if n_open >= self.cfg.max_pairs:
                    break     # portfolio is full
                if scale == 0.0:
                    break     # circuit breaker active

                sig_df = self.signal_data[pair_name]
                if date not in sig_df.index:
                    continue

                row = sig_df.loc[date]

                if row["trade_open"] and row["position"] != 0:
                    success = self._open_trade(pair_name, date, row, scale)
                    if success:
                        n_open += 1

        # --- Close any remaining open trades at end ---
        for pair_name in list(self.open_trades.keys()):
            last_date = all_dates[-1]
            if pair_name in self.signal_data:
                sig_df = self.signal_data[pair_name]
                if last_date in sig_df.index:
                    self._close_trade(pair_name, last_date, sig_df.loc[last_date], forced=True)

        return self._compile_results()

    # ------------------------------------------------------------------
    # Trade execution
    # ------------------------------------------------------------------

    def _open_trade(
        self,
        pair_name: str,
        date:      pd.Timestamp,
        row:       pd.Series,
        scale:     float,
    ) -> bool:
        """
        Open a dollar-neutral pairs position.
        Returns True if trade was successfully opened.
        """
        parts   = pair_name.split("/")
        ty, tx  = parts[0], parts[1]

        if ty not in self.prices.columns or tx not in self.prices.columns:
            return False
        if date not in self.prices.index:
            return False

        price_y = float(self.prices.loc[date, ty])
        price_x = float(self.prices.loc[date, tx])

        if np.isnan(price_y) or np.isnan(price_x) or price_y <= 0 or price_x <= 0:
            return False

        direction = int(row["position"])  # +1 or -1
        shares_y, shares_x, notional_y = self._compute_position_size(
            pair_name, row, price_y, price_x, scale
        )

        if shares_y == 0:
            return False

        # Cost
        notional_x = shares_x * price_x
        entry_cost = compute_trade_cost(
            notional_y, notional_x,
            self.cfg.commission_pct, self.cfg.slippage_pct,
        ) / 2   # half cost at entry, half at exit

        # Deduct cost from cash
        self.cash -= entry_cost

        # Dollar-neutral: long Y, short X (direction=+1) or short Y, long X (direction=-1)
        signed_shares_y = direction * shares_y
        signed_shares_x = -direction * shares_x  # opposite sign = hedge

        self.open_trades[pair_name] = OpenTrade(
            pair=pair_name,
            direction=direction,
            entry_date=date,
            entry_price_y=price_y,
            entry_price_x=price_x,
            shares_y=signed_shares_y,
            shares_x=signed_shares_x,
            entry_cost=entry_cost,
            hedge_ratio=float(row["hedge_ratio"]),
        )

        log.debug(f"  OPEN {pair_name} dir={direction:+d} "
                  f"@{price_y:.2f}/{price_x:.2f} "
                  f"shares={signed_shares_y:.0f}/{signed_shares_x:.0f} "
                  f"cost=${entry_cost:.2f}")
        return True

    def _close_trade(
        self,
        pair_name: str,
        date:      pd.Timestamp,
        row:       pd.Series,
        forced:    bool = False,
    ):
        """
        Close an open position and realise P&L.
        """
        trade = self.open_trades.pop(pair_name)
        parts = pair_name.split("/")
        ty, tx = parts[0], parts[1]

        if date not in self.prices.index:
            return

        price_y = float(self.prices.loc[date, ty])
        price_x = float(self.prices.loc[date, tx])

        if np.isnan(price_y) or np.isnan(price_x):
            return

        # Realised P&L from price moves
        pnl_y = trade.shares_y * (price_y - trade.entry_price_y)
        pnl_x = trade.shares_x * (price_x - trade.entry_price_x)
        gross_pnl = pnl_y + pnl_x

        # Exit transaction costs
        notional_y = abs(trade.shares_y) * price_y
        notional_x = abs(trade.shares_x) * price_x
        exit_cost  = compute_trade_cost(
            notional_y, notional_x,
            self.cfg.commission_pct, self.cfg.slippage_pct,
        ) / 2

        net_pnl = gross_pnl - exit_cost - trade.entry_cost

        # Add to cash
        self.cash += gross_pnl - exit_cost
        self.equity = self.cash + self._mark_to_market(date)
        # Accumulate realised P&L for per-pair loss circuit breaker
        self.pair_realised_pnl[pair_name] = (
            self.pair_realised_pnl.get(pair_name, 0.0) + net_pnl
        )

        duration = (date - trade.entry_date).days

        self.closed_trades.append({
            "pair":         pair_name,
            "direction":    "LONG" if trade.direction > 0 else "SHORT",
            "entry_date":   trade.entry_date.date(),
            "exit_date":    date.date(),
            "entry_y":      round(trade.entry_price_y, 4),
            "exit_y":       round(price_y, 4),
            "entry_x":      round(trade.entry_price_x, 4),
            "exit_x":       round(price_x, 4),
            "shares_y":     round(trade.shares_y, 2),
            "shares_x":     round(trade.shares_x, 2),
            "gross_pnl":    round(gross_pnl, 2),
            "costs":        round(exit_cost + trade.entry_cost, 2),
            "net_pnl":      round(net_pnl, 2),
            "duration_d":   duration,
            "forced_close": forced,

            "zscore_exit":  round(float(row.get("zscore_smoothed", 0)), 3),
        })

        log.debug(f"  CLOSE {pair_name} net_pnl=${net_pnl:+.2f} duration={duration}d")

    # ------------------------------------------------------------------
    # Mark-to-market
    # ------------------------------------------------------------------

    def _mark_to_market(self, date: pd.Timestamp) -> float:
        """
        Value all open positions at today's prices.
        Returns total unrealised P&L (not adding to cash yet).
        """
        if not self.open_trades or date not in self.prices.index:
            return 0.0

        total_mtm = 0.0
        for pair_name, trade in self.open_trades.items():
            parts = pair_name.split("/")
            ty, tx = parts[0], parts[1]
            if ty not in self.prices.columns or tx not in self.prices.columns:
                continue
            py = float(self.prices.loc[date, ty])
            px = float(self.prices.loc[date, tx])
            if np.isnan(py) or np.isnan(px):
                continue
            total_mtm += trade.shares_y * (py - trade.entry_price_y)
            total_mtm += trade.shares_x * (px - trade.entry_price_x)

        return total_mtm

    # ------------------------------------------------------------------
    # Compile results
    # ------------------------------------------------------------------

    def _compile_results(self) -> dict:
        """
        Package all outputs into a results dict for the dashboard.
        """
        equity_df = pd.DataFrame(self.equity_curve).set_index("date")
        trades_df = pd.DataFrame(self.closed_trades)

        metrics = portfolio_risk_report(equity_df["equity"])

        # Per-pair P&L breakdown
        if not trades_df.empty:
            pair_pnl = (
                trades_df.groupby("pair")["net_pnl"]
                .agg(["sum", "count", "mean"])
                .rename(columns={"sum": "total_pnl", "count": "n_trades", "mean": "avg_pnl"})
                .sort_values("total_pnl", ascending=False)
                .round(2)
            )
        else:
            pair_pnl = pd.DataFrame()

        return {
            "equity_curve": equity_df,
            "trades":       trades_df,
            "pair_pnl":     pair_pnl,
            "metrics":      metrics,
        }


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import os
    from data_pipeline import download_prices, validate_and_clean
    from signal_generator import run_all_signals

    cfg = CFG
    os.makedirs("results", exist_ok=True)

    print("\n" + "="*60)
    print("  SPRINT 3 — BACKTESTER")
    print("="*60)

    # Load data
    all_tickers = [t for tickers in cfg.sectors.values() for t in tickers]
    raw_prices  = download_prices(all_tickers, cfg.data.start_date, cfg.data.end_date)
    prices, _   = validate_and_clean(raw_prices, cfg.data.min_history)

    # Load screening results
    ranked_pairs   = pd.read_csv("results/ranked_pairs.csv")
    spread_quality = pd.read_csv("results/spread_quality.csv")

    # Re-run signals (needed for the backtester)
    print("\nBuilding signals...")
    signal_data, all_trades, signal_stats = run_all_signals(
        prices, ranked_pairs, cfg.signal, top_n=10
    )

    # Run backtest
    print("\nRunning event-driven backtest...\n")
    bt = PairsBacktester(
        prices=prices,
        signal_data=signal_data,
        ranked_pairs=ranked_pairs,
        signal_stats=signal_stats,
        spread_quality=spread_quality,
        cfg=cfg.risk,
    )
    results = bt.run()

    if not results:
        print("No results — check pair approval filters")
    else:
        eq  = results["equity_curve"]
        trd = results["trades"]
        m   = results["metrics"]

        print(f"\n{'='*60}")
        print(f"  BACKTEST RESULTS")
        print(f"{'='*60}")
        print(f"  Period:         {eq.index[0].date()} → {eq.index[-1].date()}")
        print(f"  Starting cap:   ${cfg.risk.capital:>12,.2f}")
        print(f"  Ending equity:  ${eq['equity'].iloc[-1]:>12,.2f}")
        print(f"")
        print(f"  Total return:   {m['total_return_pct']:>+8.2f}%")
        print(f"  Ann. return:    {m['ann_return_pct']:>+8.2f}%")
        print(f"  Ann. vol:       {m['ann_vol_pct']:>8.2f}%")
        print(f"  Sharpe ratio:   {m['sharpe_ratio']:>8.3f}")
        print(f"  Sortino ratio:  {m['sortino_ratio']:>8.3f}")
        print(f"  Calmar ratio:   {m['calmar_ratio']:>8.3f}")
        print(f"  Max drawdown:   {m['max_drawdown_pct']:>8.2f}%")
        print(f"  Win days:       {m['win_days_pct']:>8.1f}%")
        print(f"  N trades:       {len(trd):>8d}")
        print(f"{'='*60}")

        if not results["pair_pnl"].empty:
            print(f"\n--- P&L by Pair ---")
            print(results["pair_pnl"].to_string())

        # Save all outputs
        eq.to_csv("results/equity_curve.csv")
        trd.to_csv("results/backtest_trades.csv", index=False)
        results["pair_pnl"].to_csv("results/pair_pnl.csv")
        pd.DataFrame([m]).to_csv("results/metrics.csv", index=False)

        print(f"\n✓ Results saved to results/")
        print(f"  Next step: run walk_forward.py (Sprint 4)")
