"""
pair_screener.py — Find cointegrated pairs in each sector.

CONCEPT: What is cointegration?
  Two stocks can be individually non-stationary (prices wander randomly,
  like a random walk) but still be "bound together" in the long run.
  Think of a drunk walking a dog on a leash — both paths are random, but
  the distance between them is bounded and mean-reverting. That distance
  is the "spread" we trade.

  Formally, if X and Y are I(1) (integrated order 1 — i.e., their
  first differences are stationary), and some linear combination
      S_t = Y_t - β * X_t
  is I(0) (stationary), then X and Y are cointegrated with hedge ratio β.

CONCEPT: Engle-Granger two-step test
  Step 1: Regress Y on X to get β (OLS). This is the hedge ratio.
  Step 2: Run an ADF (Augmented Dickey-Fuller) test on the residuals S_t.
          If p-value < 0.05, we reject the null of a unit root → S_t is
          stationary → pair is cointegrated.

CONCEPT: Half-life of mean reversion
  If S_t is an Ornstein-Uhlenbeck (OU) process:
      dS = κ(μ - S)dt + σdW
  then the half-life is ln(2)/κ. We estimate κ by regressing
      ΔS_t on S_{t-1}
  The half-life tells us how quickly the spread reverts to its mean.
  Too short (<5 days) → noise, transaction costs kill you.
  Too long (>63 days) → capital tied up, slow signal.

CONCEPT: Chow structural break test
  A pair can pass the Engle-Granger test on a 6-year window but still be
  untradeable if the cointegrating relationship broke down mid-period.
  IR/ITW is a perfect example: Ingersoll Rand spun off its industrial
  segment in 2020, permanently changing its fundamental business. The
  pre-2020 history looked cointegrated; the post-2020 relationship was
  completely different.

  The Chow test splits the training window at the midpoint and tests
  whether the OLS regression coefficients (hedge ratio) are statistically
  equal in both halves. If the F-statistic is significant (p < 0.05),
  we reject the pair — the relationship is structurally unstable.

  Formally: fit OLS on full period (RSS_total), fit OLS on each half
  separately (RSS_1, RSS_2), then:
      F = [(RSS_total - RSS_1 - RSS_2) / k] / [(RSS_1 + RSS_2) / (n - 2k)]
  where k = number of parameters (2: intercept + slope), n = total obs.
  This F-statistic follows F(k, n-2k) under the null of no break.
"""

import itertools
import logging
import warnings
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
from scipy import stats
from statsmodels.regression.linear_model import OLS
from statsmodels.tools import add_constant
from statsmodels.tsa.stattools import adfuller, coint

from config import CFG, ScreenConfig

warnings.filterwarnings("ignore")
log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Result container
# ---------------------------------------------------------------------------

@dataclass
class PairResult:
    """All statistics for one candidate pair."""
    sector:         str
    ticker_y:       str       # dependent variable (we go long/short this)
    ticker_x:       str       # independent variable (the "driver")
    hedge_ratio:    float     # β from OLS regression
    coint_pvalue:   float     # Engle-Granger p-value (lower = stronger)
    adf_pvalue:     float     # ADF on spread residuals
    half_life:      float     # days to half-reversion
    correlation:    float     # Pearson correlation of returns
    spread_mean:    float     # long-run mean of the spread
    spread_std:     float     # standard deviation of the spread
    hurst_exp:      float     # Hurst exponent (< 0.5 = mean-reverting)
    score:          float     # composite ranking score (higher = better)

    def __str__(self):
        return (
            f"{self.ticker_y}/{self.ticker_x} | "
            f"p={self.coint_pvalue:.3f} | "
            f"HL={self.half_life:.1f}d | "
            f"H={self.hurst_exp:.3f} | "
            f"score={self.score:.3f}"
        )


# ---------------------------------------------------------------------------
# Individual statistical tests
# ---------------------------------------------------------------------------

def estimate_hedge_ratio(price_y: pd.Series, price_x: pd.Series) -> Tuple[float, pd.Series]:
    """
    OLS regression of log(Y) on log(X) to get hedge ratio β.

    We use LOG prices (not raw prices) so that β is in return-space,
    meaning a 1% move in X predicts a β% move in Y. This makes β
    comparable across different price levels.

    Returns: (hedge_ratio, spread_series)
    """
    log_y = np.log(price_y)
    log_x = np.log(price_x)

    X = add_constant(log_x)
    model = OLS(log_y, X).fit()
    beta = model.params.iloc[1]
    spread = log_y - beta * log_x   # the residual series we'll trade
    return float(beta), spread


def estimate_half_life(spread: pd.Series) -> float:
    """
    Estimate half-life of mean reversion via OU process regression.

    Regress ΔS_t on S_{t-1}:
        ΔS_t = α + κ * S_{t-1} + ε_t

    κ is the speed of mean reversion. half_life = -ln(2) / κ
    A negative κ means the spread pulls back toward its mean.
    """
    delta_s = spread.diff().dropna()
    lagged_s = spread.shift(1).dropna()

    # Align
    delta_s, lagged_s = delta_s.align(lagged_s, join="inner")

    X = add_constant(lagged_s)
    model = OLS(delta_s, X).fit()
    kappa = model.params.iloc[1]

    if kappa >= 0:
        return float("inf")  # not mean-reverting

    half_life = -np.log(2) / kappa
    return float(half_life)


def hurst_exponent(series: pd.Series, max_lag: int = 100) -> float:
    """
    Estimate the Hurst exponent via rescaled range analysis.

    CONCEPT:
      H < 0.5 → mean-reverting (anti-persistent) ← we want this
      H = 0.5 → random walk (no edge)
      H > 0.5 → trending (momentum)

    We compute the variance of lags at different scales and fit a
    power law: Var(τ) ∝ τ^(2H). The slope in log-log space = 2H.
    """
    series = series.dropna()
    lags = range(2, min(max_lag, len(series) // 2))
    tau = []
    reg = []

    for lag in lags:
        tau.append(lag)
        reg.append(np.std(np.subtract(series[lag:], series[:-lag])))

    # Fit log-log regression
    log_lags = np.log(tau)
    log_reg = np.log(reg)
    poly = np.polyfit(log_lags, log_reg, 1)
    return float(poly[0])   # slope = H



def chow_structural_break_test(
    spread: pd.Series,
    split_ratio: float = 0.5,
    significance: float = 0.05,
) -> Tuple[bool, float]:
    """
    Chow test for structural break in the spread series.

    Splits the spread at split_ratio (default: midpoint) and tests whether
    the OLS regression of ΔS on S_{t-1} has stable coefficients across both
    halves. A significant break means the mean-reversion dynamics changed
    mid-period — the pair is not safe to trade going forward.

    Returns:
        (break_detected: bool, p_value: float)
        break_detected=True means REJECT this pair.
    """
    spread = spread.dropna()
    n = len(spread)
    if n < 60:
        return False, 1.0   # not enough data to test — pass through

    # OU regression: ΔS_t = α + κ·S_{t-1} + ε
    delta_s = spread.diff().dropna()
    lagged  = spread.shift(1).dropna()
    delta_s, lagged = delta_s.align(lagged, join="inner")

    X_full = add_constant(lagged)
    k = X_full.shape[1]   # number of parameters (2: intercept + slope)

    # Full-period residual sum of squares
    model_full = OLS(delta_s, X_full).fit()
    rss_full   = float(np.sum(model_full.resid ** 2))

    # Split-period RSS
    split_idx = int(len(delta_s) * split_ratio)
    rss_parts = 0.0
    for start, end in [(0, split_idx), (split_idx, len(delta_s))]:
        segment_y = delta_s.iloc[start:end]
        segment_x = X_full.iloc[start:end]
        if len(segment_y) < k + 2:
            return False, 1.0   # segment too small — skip test
        model_part = OLS(segment_y, segment_x).fit()
        rss_parts += float(np.sum(model_part.resid ** 2))

    # Chow F-statistic
    n_obs  = len(delta_s)
    denom  = (rss_full - rss_parts) / k
    numer  = rss_parts / (n_obs - 2 * k)
    if numer <= 0:
        return False, 1.0

    f_stat = denom / numer
    # p-value: P(F(k, n-2k) > f_stat) under null of no break
    from scipy.stats import f as f_dist
    p_value = float(1 - f_dist.cdf(f_stat, dfn=k, dfd=n_obs - 2 * k))

    break_detected = p_value < significance
    return break_detected, p_value


def score_pair(result: PairResult) -> float:
    """
    Composite score to rank pairs. Higher = more tradeable.

    We combine:
      - Low cointegration p-value (strongest statistical signal)
      - Half-life in the sweet spot (not too fast, not too slow)
      - Low Hurst exponent (strong mean reversion)
      - High correlation (pairs share common factor)

    Weights are tunable — this is a design choice, not a fact.
    """
    # p-value score: lower p = higher score (exponential reward)
    p_score = np.exp(-10 * result.coint_pvalue)

    # Half-life score: peaks at 20 days, falls off on both sides
    hl_target = 20.0
    hl_score = np.exp(-((result.half_life - hl_target) / 30) ** 2)

    # Hurst score: lower H = better (cap at 0.5)
    h_score = max(0, 0.5 - result.hurst_exp) * 2

    # Correlation score
    corr_score = max(0, result.correlation - 0.7) / 0.3  # 0 at 0.7, 1 at 1.0

    # Weighted sum
    score = 0.40 * p_score + 0.25 * hl_score + 0.20 * h_score + 0.15 * corr_score
    return float(score)


# ---------------------------------------------------------------------------
# Main screening function
# ---------------------------------------------------------------------------

def screen_pairs(
    prices: pd.DataFrame,
    sector: str,
    cfg: ScreenConfig = None,
) -> List[PairResult]:
    """
    Test all pairs in a sector and return those passing all filters.

    Steps for each candidate pair (Y, X):
      1. Pre-filter: correlation check (fast, eliminates ~60% of pairs)
      2. Engle-Granger cointegration test
      3. ADF test on the spread residuals
      4. Estimate hedge ratio, half-life, Hurst exponent
      5. Apply all threshold filters
      6. Hurst exponent check
      7. Chow structural break test (rejects mid-period regime changes)
      8. Score and rank survivors
    """
    cfg = cfg or CFG.screen
    tickers = list(prices.columns)
    candidates = list(itertools.combinations(tickers, 2))
    log.info(f"  [{sector}] Testing {len(candidates)} pairs from {len(tickers)} tickers")

    # Pre-compute log returns for correlation screening
    log_returns = np.log(prices / prices.shift(1)).dropna()
    results = []

    for ticker_y, ticker_x in candidates:
        try:
            series_y = prices[ticker_y].dropna()
            series_x = prices[ticker_x].dropna()

            # Align both series to the same dates
            series_y, series_x = series_y.align(series_x, join="inner")
            if len(series_y) < 252:
                continue

            # --- STEP 1: Quick correlation pre-filter ---
            ret_y = log_returns[ticker_y].dropna()
            ret_x = log_returns[ticker_x].dropna()
            ret_y, ret_x = ret_y.align(ret_x, join="inner")
            correlation = float(ret_y.corr(ret_x))

            if abs(correlation) < cfg.min_correlation:
                continue  # too uncorrelated to form a reliable pair

            # --- STEP 2: Engle-Granger cointegration test ---
            # statsmodels coint() handles the OLS + ADF internally
            coint_stat, coint_pvalue, _ = coint(
                np.log(series_y),
                np.log(series_x),
                trend="c",
            )

            if coint_pvalue > cfg.coint_pvalue_threshold:
                continue

            # --- STEP 3: Estimate hedge ratio and spread ---
            hedge_ratio, spread = estimate_hedge_ratio(series_y, series_x)

            # --- STEP 4: ADF test on the spread directly ---
            adf_stat, adf_pvalue, *_ = adfuller(spread, maxlags=1, autolag=None)

            if adf_pvalue > cfg.adf_pvalue_threshold:
                continue

            # --- STEP 5: Half-life ---
            half_life = estimate_half_life(spread)

            if not (cfg.min_half_life <= half_life <= cfg.max_half_life):
                continue

            # --- STEP 6: Hurst exponent ---
            hurst = hurst_exponent(spread)

            # --- STEP 7: Chow structural break test ---
            # Rejects pairs whose cointegrating relationship changed mid-period
            # (e.g. corporate restructurings, spin-offs, major M&A events).
            if getattr(cfg, "chow_test_enabled", True):
                break_detected, chow_p = chow_structural_break_test(
                    spread, split_ratio=getattr(cfg, "chow_split_ratio", 0.5)
                )
                if break_detected:
                    log.debug(f"  Chow break detected {ticker_y}/{ticker_x} "
                              f"(p={chow_p:.3f}) — rejecting")
                    continue

            # Build result
            result = PairResult(
                sector=sector,
                ticker_y=ticker_y,
                ticker_x=ticker_x,
                hedge_ratio=hedge_ratio,
                coint_pvalue=coint_pvalue,
                adf_pvalue=adf_pvalue,
                half_life=half_life,
                correlation=correlation,
                spread_mean=float(spread.mean()),
                spread_std=float(spread.std()),
                hurst_exp=hurst,
                score=0.0,  # filled in below
            )
            result.score = score_pair(result)
            results.append(result)

        except Exception as e:
            log.debug(f"  Error on {ticker_y}/{ticker_x}: {e}")
            continue

    # Sort by composite score
    results.sort(key=lambda r: r.score, reverse=True)
    log.info(f"  [{sector}] {len(results)} pairs passed all filters")
    return results


def screen_all_sectors(
    sector_universe: Dict[str, pd.DataFrame],
    cfg: ScreenConfig = None,
    top_n_per_sector: int = 5,
) -> pd.DataFrame:
    """
    Run pair screening across all sectors and return a ranked DataFrame.
    """
    cfg = cfg or CFG.screen
    all_results = []

    for sector, prices in sector_universe.items():
        log.info(f"\nScreening sector: {sector.upper()}")
        sector_results = screen_pairs(prices, sector, cfg)
        # Take top N from each sector
        all_results.extend(sector_results[:top_n_per_sector])

    if not all_results:
        log.warning("No pairs survived screening!")
        return pd.DataFrame()

    rows = []
    for r in all_results:
        rows.append({
            "sector":       r.sector,
            "pair":         f"{r.ticker_y}/{r.ticker_x}",
            "ticker_y":     r.ticker_y,
            "ticker_x":     r.ticker_x,
            "score":        round(r.score, 4),
            "coint_pvalue": round(r.coint_pvalue, 4),
            "half_life":    round(r.half_life, 1),
            "hedge_ratio":  round(r.hedge_ratio, 4),
            "hurst_exp":    round(r.hurst_exp, 3),
            "correlation":  round(r.correlation, 3),
            "spread_std":   round(r.spread_std, 4),
        })

    df = pd.DataFrame(rows).sort_values("score", ascending=False).reset_index(drop=True)
    return df


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import os
    from data_pipeline import download_prices, validate_and_clean, build_sector_universe

    cfg = CFG
    os.makedirs("data", exist_ok=True)
    os.makedirs("results", exist_ok=True)

    print("\n" + "="*60)
    print("  SPRINT 1 — PAIR SCREENER")
    print("="*60)

    # Load data
    all_tickers = [t for tickers in cfg.sectors.values() for t in tickers]
    raw_prices = download_prices(all_tickers, cfg.data.start_date, cfg.data.end_date)
    prices, _ = validate_and_clean(raw_prices, cfg.data.min_history)
    universe = build_sector_universe(prices, cfg.sectors)

    # Screen
    print("\nRunning cointegration screening...")
    ranked_pairs = screen_all_sectors(universe, cfg.screen, top_n_per_sector=5)

    # Display results
    if ranked_pairs.empty:
        print("No pairs found — try relaxing thresholds in config.py")
    else:
        print(f"\n{'='*60}")
        print(f"  TOP PAIRS FOUND: {len(ranked_pairs)}")
        print(f"{'='*60}")
        pd.set_option("display.max_columns", None)
        pd.set_option("display.width", 120)
        print(ranked_pairs.to_string(index=True))

        # Save for Sprint 2
        ranked_pairs.to_csv("results/ranked_pairs.csv", index=False)
        print(f"\n✓ Saved to results/ranked_pairs.csv")
        print(f"  Next step: run spread_model.py (Sprint 2)")
